/*
 * File:   main.cpp
 * Author: Justin Gutierrez
 * Created on June 26, 2022, 5:02 PM
 * Purpose: Personal Information Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout<<"Justin Gutierrez"<<endl<<"1234 Street Ave, Eastvale, CA, 92880"
            <<endl<<"(123) 456 - 789"<<endl<<"Political Science";
            
    
    
    //Exit Stage right
    return 0;
}

